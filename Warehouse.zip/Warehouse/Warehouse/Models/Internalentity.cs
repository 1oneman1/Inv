﻿using System;
using System.Collections.Generic;

namespace Warehouse.Models;

public partial class Internalentity
{
    public int InternalEntityId { get; set; }

    public string EntityName { get; set; } = null!;

    public string? EntityInfo { get; set; }

    public virtual ICollection<Userentity> Userentities { get; set; } = new List<Userentity>();
}
