﻿using System;
using System.Collections.Generic;

namespace Warehouse.Models;

public partial class Inventory
{
    public int InventoryId { get; set; }

    public int? ProductId { get; set; }

    public string? SerialNumber { get; set; }

    public int? SupplierId { get; set; }

    public DateOnly ReceivedDate { get; set; }

    public string ReferenceNumber { get; set; } = null!;

    public string Status { get; set; } = null!;

    public int? AssignedUserId { get; set; }

    public DateOnly? AssignedDate { get; set; }

    public int? ManufacturedProductId { get; set; }

    public DateOnly? DecomposedDate { get; set; }

    public DateOnly? DestroyedDate { get; set; }

    public DateOnly? ManufacturedDate { get; set; }

    public string? Notes { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual User? AssignedUser { get; set; }

    public virtual ICollection<Inventory> InverseManufacturedProduct { get; set; } = new List<Inventory>();

    public virtual Inventory? ManufacturedProduct { get; set; }

    public virtual Product? Product { get; set; }

    public virtual Supplier? Supplier { get; set; }
}
