﻿using System;
using System.Collections.Generic;

namespace Warehouse.Models;

public partial class Userentity
{
    public int UserEntityId { get; set; }

    public int? UserId { get; set; }

    public int? InternalEntityId { get; set; }

    public DateOnly StartDate { get; set; }

    public DateOnly? EndDate { get; set; }

    public virtual Internalentity? InternalEntity { get; set; }

    public virtual User? User { get; set; }
}
